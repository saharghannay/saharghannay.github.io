################
## Sahar Ghannay
## LISN
## 15/01/2025


# Semantic representation session

you will find here the scripts you need for the second practical session

Two scripts 

- cnn_classification.py:  to run LSTM and CNN models
- transformer.py: another to run Transformer models (BERT)

A requirement file contains some required librairies

